#!/usr/bin/python

import mido

def inspect(filename):
    mid = mido.MidiFile(filename)
    f = open("out.txt", "w")
    for i, track in enumerate(mid.tracks):
        print('Track {}: {}'.format(i, track.name))
        for message in track:
        	#print(message)
        	f.write(str(message) + "\n")
    f.close

if __name__ == '__main__':
    import sys
    if len(sys.argv) == 2:
        inspect(sys.argv[1])
